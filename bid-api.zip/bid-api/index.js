const express = require('express');
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');
const Bid = require('./Models/Bid');

const app = express();
const PORT = 8000;

app.use(express.json());
app.use(cors())

mongoose.connect('mongodb+srv://saiatelly:atelly$6699@bidding-engine.z179m.mongodb.net/', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('Failed to connect to MongoDB', err);
});

app.post('/create-bid', async (req, res) => {
    const { title, createdBy, startingPrice, endTime } = req.body;

    if (!title || !createdBy || !startingPrice || !endTime) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const bid = new Bid({
            uniqueId: uuidv4(),
            title,
            createdBy,
            startingPrice,
            endTime, 
            bids: []
        });

        await bid.save();

        return res.status(201).json(bid);
    } catch (err) {
        return res.status(500).json({ error: 'Failed to create bid' });
    }
});


app.get('/bids', async(req,res) => {
    try {
        const bids = await Bid.find();
        return res.status(200).json(bids);
    } catch (err) {
        return res.status(500).json({ error: 'Failed to add bid' });
    }

})

app.post('/add-bid/:uniqueId', async (req, res) => {
    const { uniqueId } = req.params;
    const { name, bidPrice } = req.body;

    if (!name || !bidPrice) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const bid = await Bid.findOne({ uniqueId });

        if (!bid) {
            return res.status(404).json({ error: 'Bid not found' });
        }
        console.log(bid, 'bidddddd')
        bid.bids.push({ name, bidPrice });

        await bid.save(); 

        return res.status(201).json(bid);
    } catch (err) {
        console.log(err)
        return res.status(500).json({ error: 'Failed to add bid' });
    }
});

app.put('/add-bid/:uniqueId', async (req, res) => {
    const { uniqueId } = req.params;
    console.log(uniqueId, 'uniqueId')
    const { name, bidPrice } = req.body;

    if (!name || !bidPrice) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const bid = await Bid.findOne({ uniqueId });
        console.log(bid, 'postBid')

        if (!bid) {
            return res.status(404).json({ error: 'Bid not found' });
        }

        const existingBid = bid.bids.find(b => b.name == name);

        if (existingBid) {
            existingBid.bidPrice = bidPrice;

            await bid.save();

            return res.status(200).json({ message: 'Bid updated successfully', bid });
        } else {
            return res.status(404).json({ error: 'Name not found in bids' });
        }
    } catch (err) {
        return res.status(500).json({ error: 'Failed to update bid' });
    }
});


app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
