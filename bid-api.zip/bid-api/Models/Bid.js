const mongoose = require('mongoose');

const bidSchema = new mongoose.Schema({
    uniqueId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true
    },
    createdBy: {
        type: String,
        required: true
    },
    startingPrice: {
        type: Number,
        required: true
    },
    endTime: {
        type: String,
        required: true
    },
    bids: [
        {
            name: String,
            bidPrice: Number
        }
    ]
});

const Bid = mongoose.model('Bid', bidSchema);

module.exports = Bid;
